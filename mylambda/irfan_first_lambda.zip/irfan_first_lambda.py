def lambda_handler(event, context):
    print("Hello, this is Irfans first lambda using terraform")
    return "Successful Irfan Test Lambda"